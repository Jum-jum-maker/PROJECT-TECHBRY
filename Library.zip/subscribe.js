const button = document.getElementsByClassName("button");

button.addEventListener("click", button);

function button(){
    
    console.log('welcome');
    alert('welcome to make your first subscription!');
}
   